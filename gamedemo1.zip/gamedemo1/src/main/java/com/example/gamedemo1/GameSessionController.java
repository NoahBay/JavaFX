package com.example.gamedemo1;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.scene.Node;
import java.io.IOException;
import java.util.*;

import javafx.scene.control.Label;

public class GameSessionController {
    ScoreSystem scoreSystem = new ScoreSystem();
    StopWatch stopWatch = new StopWatch();
    public LinkedHashMap<String, String> questionAndAnswer = new LinkedHashMap<>();
    public ArrayList<String> questionsRecieved = new ArrayList<>();
    private Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    private Label InformationLabel;
    @FXML
    private RadioButton rButton1, rButton2, rButton3, rButton4, rButton5, rButton6, rButton7;
    @FXML
    Button BackButton;
    @FXML
    ImageView image1;

    public void informationScene(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("InformationScene.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }

    public void getInformation(ActionEvent event) throws IOException {
        if (rButton1.isSelected()) {
            InformationLabel.setText(
                    "Information 1"
            );
        } else if (rButton2.isSelected()) {
            InformationLabel.setText(
                    "Information 2"
            );
        } else if (rButton3.isSelected()) {
            InformationLabel.setText(
                    "Information 3"
            );
        } else if (rButton4.isSelected()) {
            InformationLabel.setText(
                    "Information 4"
            );
        } else if (rButton5.isSelected()) {
            InformationLabel.setText(
                    "Information 5"
            );
        } else if (rButton6.isSelected()) {
            InformationLabel.setText(
                    "Information 6"
            );
        } else if (rButton7.isSelected()) {
            InformationLabel.setText(
                    "Information 7"
            );
        }
    }

    public void mainMenu(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("MainMenuScene.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }

    public void HelpScene(ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass()).getResource("MainMenuHelp.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }

    public void HelpSceneInformation(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("InformationHelp.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }

    public void gameScene(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("WorldMap.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

        // Setting the questions and answers
        questionAndAnswer.put("Skal man slukke sit ulovlige bål, når man er færdig med at bruge det?", "Ja");
        questionAndAnswer.put("Hvor mange procent af skovbrande er menneskeskabte? \n" +
                "1: 30-45%\n" +
                "2: 50-60%\n" +
                "3: 75-90%", "3");
        questionAndAnswer.put("Hvis en naturlig skovbrand starter, skal man så slukke den?", "Nej");
        questionAndAnswer.put("Hvor mange huse blev ødelagt af skovbrande i Australien i 2020\n" +
                "1: 1365\n" +
                "2: 2439\n" +
                "3: 3698", "2");
        questionAndAnswer.put("Hvor mange millioner hektar skov var der blevet brandt af i amazonas i 2020\n" +
                "1: 4.5 millioner\n" +
                "2: 5.1 millioner\n" +
                "3: 5.5 millioner", "3");
    }

    public void QuestionAndAnswer(ActionEvent event) throws IOException {
        Random random = new Random();
        int number = random.nextInt(questionAndAnswer.size());

        // Question
        Set<String> keySet = questionAndAnswer.keySet();
        List<String> listKeys = new ArrayList<String>(keySet);
        String key = listKeys.get(number);

        // Answer
        Object firstKey = questionAndAnswer.keySet().toArray()[number];
        Object valueForFirstKey = questionAndAnswer.get(firstKey);
    }

    public void USA(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("USA.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        stage.setResizable(false);
    }
}
